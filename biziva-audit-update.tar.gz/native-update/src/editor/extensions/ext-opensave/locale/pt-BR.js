export default { opensave: { new_doc: 'Nova imagem', open_image_doc: 'Abrir SVG', save_doc: 'Salvar SVG', save_as_doc: 'Salvar SVG como' } }
