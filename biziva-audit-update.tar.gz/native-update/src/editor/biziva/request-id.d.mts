export declare function generationRequestId(cryptoApi: Pick<Crypto, "subtle">, key: string, payload: unknown, scope: string): Promise<string>;
